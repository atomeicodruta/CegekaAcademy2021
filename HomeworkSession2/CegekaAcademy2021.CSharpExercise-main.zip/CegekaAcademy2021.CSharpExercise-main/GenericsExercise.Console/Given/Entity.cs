﻿namespace GenericsExercise
{
    public interface IEntity
    {
        string Id { get; set; }
    }
}
